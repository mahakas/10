from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from backend_v2.retrieval.hybrid import HybridReranker
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.threshold import RetrievalDecision, RetrievalThreshold
from backend_v2.vectorstores.base import VectorHit, VectorStore
from backend_v2.vectorstores.embedding import EmbeddingService


@dataclass(frozen=True, slots=True)
class RetrievalRequest:
    query: str
    scope: RetrievalScope
    collection: str
    top_k: int = 8
    candidate_k: int = 24
    min_score: float = 0.35


@dataclass(frozen=True, slots=True)
class RetrievalResult:
    accepted: list[VectorHit]
    rejected: list[VectorHit]
    embedding_provider: str
    embedding_model: str
    embedding_dimension: int
    filters: dict[str, Any]

    @property
    def found(self) -> bool:
        return bool(self.accepted)


class RetrievalService:
    """End-to-end query retrieval: scope -> embed -> vector search -> rerank -> threshold."""

    def __init__(
        self,
        vector_store: VectorStore,
        embedding_service: EmbeddingService,
        *,
        reranker: HybridReranker | None = None,
    ) -> None:
        self.vector_store = vector_store
        self.embedding_service = embedding_service
        self.reranker = reranker or HybridReranker()

    def retrieve(self, request: RetrievalRequest) -> RetrievalResult:
        query = str(request.query).strip()
        if not query:
            raise ValueError("Retrieval query cannot be empty")
        if request.top_k <= 0 or request.candidate_k <= 0:
            raise ValueError("top_k and candidate_k must be positive")

        embedding = self.embedding_service.embed([query])
        filters = request.scope.as_filters()
        vector_hits = self.vector_store.search(
            embedding.vectors[0],
            collection=request.collection,
            top_k=max(request.candidate_k, request.top_k),
            filters=filters or None,
        )
        reranked = self.reranker.rerank(query, vector_hits, top_k=request.top_k)
        decision: RetrievalDecision = RetrievalThreshold(request.min_score).apply(reranked)
        return RetrievalResult(
            accepted=decision.accepted,
            rejected=decision.rejected,
            embedding_provider=embedding.provider,
            embedding_model=embedding.model,
            embedding_dimension=embedding.dimension,
            filters=filters,
        )
