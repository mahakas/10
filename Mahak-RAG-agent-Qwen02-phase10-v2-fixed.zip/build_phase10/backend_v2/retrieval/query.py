from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class RetrievalScope:
    grade_id: str | None = None
    subject_id: str | None = None
    course_id: str | None = None
    chapter_id: str | None = None
    lesson_id: str | None = None
    source_ids: tuple[str, ...] = ()
    session_file_ids: tuple[str, ...] = ()

    def as_filters(self) -> dict[str, object]:
        filters: dict[str, object] = {}
        for key in ("grade_id", "subject_id", "course_id", "chapter_id", "lesson_id"):
            value = getattr(self, key)
            if value:
                filters[key] = value
        if self.source_ids:
            filters["source_id"] = {"$in": list(self.source_ids)}
        if self.session_file_ids:
            filters["session_file_id"] = {"$in": list(self.session_file_ids)}
        return filters
