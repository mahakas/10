from __future__ import annotations

from dataclasses import dataclass
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from backend_v2.vectorstores.base import VectorHit


@dataclass(frozen=True, slots=True)
class CitationRef:
    source_id: str | None
    title: str
    url: str | None = None
    page: int | None = None
    start_time_seconds: int | None = None
    end_time_seconds: int | None = None
    preview: str | None = None
    metadata: dict[str, Any] | None = None


def citation_from_hit(hit: "VectorHit") -> CitationRef:
    """Build a source-aware citation from a retrieval hit's normalized metadata."""
    metadata = dict(hit.metadata)
    return CitationRef(
        source_id=metadata.get("source_id"),
        title=str(metadata.get("title") or metadata.get("source_title") or "منبع"),
        url=metadata.get("url") or metadata.get("original_url"),
        page=_safe_int(metadata.get("page")),
        start_time_seconds=_safe_int(metadata.get("start_time_seconds")),
        end_time_seconds=_safe_int(metadata.get("end_time_seconds")),
        preview=hit.document[:300],
        metadata=metadata,
    )


def _safe_int(value: object) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None
