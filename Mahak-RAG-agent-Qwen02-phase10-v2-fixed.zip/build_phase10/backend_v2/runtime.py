from __future__ import annotations

from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.vectorstores.embedding import EmbeddingService
from backend_v2.vectorstores.memory import InMemoryVectorStore


class V2Runtime:
    """Process-local runtime shared by APIs so uploaded session vectors are queryable by chat."""

    def __init__(self) -> None:
        self.registry = ProviderRegistry()
        self.health = ProviderHealthManager()
        self.vector_store = InMemoryVectorStore()
        self.registry.register(
            MockProviderAdapter(
                "default-embedding",
                {Capability.EMBEDDING},
                default_model="embed-v1",
                embedding_dimension=8,
            ),
            priority=1,
        )
        self.registry.register(
            MockProviderAdapter(
                "default-chat",
                {Capability.CHAT},
                default_model="chat-v1",
                handler=lambda payload: "پاسخ آموزشی تولیدشده بر اساس منابع بازیابی‌شده.",
            ),
            priority=1,
        )
        self.embedding_orchestrator = ProviderOrchestrator(self.registry, self.health)
        self.llm_orchestrator = ProviderOrchestrator(self.registry, self.health)
        self.embedding = EmbeddingService(self.embedding_orchestrator)


runtime = V2Runtime()
