from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from backend_v2.retrieval.citation_builder import CitationRef, citation_from_hit
from backend_v2.vectorstores.base import VectorHit


@dataclass(frozen=True, slots=True)
class AnswerContext:
    passages: tuple[str, ...]
    citations: tuple[CitationRef, ...]


def build_answer_context(hits: Iterable[VectorHit], *, max_chars: int = 12000) -> AnswerContext:
    passages: list[str] = []
    citations: list[CitationRef] = []
    total = 0
    for hit in hits:
        block = hit.document.strip()
        if not block:
            continue
        remaining = max_chars - total
        if remaining <= 0:
            break
        block = block[:remaining]
        passages.append(block)
        citations.append(citation_from_hit(hit))
        total += len(block)
    return AnswerContext(tuple(passages), tuple(citations))
