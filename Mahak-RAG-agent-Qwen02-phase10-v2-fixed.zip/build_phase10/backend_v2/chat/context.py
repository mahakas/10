from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from backend_v2.core.enums import ChatMode


@dataclass(slots=True)
class ConversationContext:
    conversation_id: str
    user_id: str | None
    mode: ChatMode
    grade_id: str | None = None
    subject_id: str | None = None
    course_id: str | None = None
    chapter_id: str | None = None
    lesson_id: str | None = None
    session_file_ids: list[str] = field(default_factory=list)
    messages: list[dict[str, Any]] = field(default_factory=list)

    def add_message(self, role: str, content: str, **metadata: Any) -> None:
        self.messages.append({"role": role, "content": content, "metadata": metadata})
