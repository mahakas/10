from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from uuid import uuid4

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend_v2.chat.general import FileContext
from backend_v2.core.enums import SourceScope, SourceStatus
from backend_v2.database.models import Conversation, IngestionJob, SessionFile, Source, SourceVersion
from backend_v2.ingestion.pipeline import IngestionPipeline
from backend_v2.retrieval.session_index import SessionIndexService


@dataclass(frozen=True, slots=True)
class SessionFileResult:
    session_file: SessionFile
    source: Source
    warnings: tuple[str, ...]
    ready_for_context: bool


class SessionFileService:
    """Persists and processes files uploaded for a single conversation."""

    def __init__(
        self,
        db: Session,
        *,
        storage_root: Path,
        pipeline: IngestionPipeline | None = None,
        session_index: SessionIndexService | None = None,
    ) -> None:
        self.db = db
        self.storage_root = Path(storage_root)
        self.pipeline = pipeline or IngestionPipeline()
        self.session_index = session_index

    def ensure_conversation(self, conversation_id: str, *, mode: str) -> Conversation:
        conversation = self.db.get(Conversation, conversation_id)
        if conversation is not None:
            return conversation
        conversation = Conversation(id=conversation_id, mode=mode)
        self.db.add(conversation)
        self.db.flush()
        return conversation

    def save_upload(
        self,
        *,
        conversation_id: str,
        mode: str,
        filename: str,
        content: bytes,
        mime_type: str | None = None,
        grade_id: str | None = None,
        subject_id: str | None = None,
        course_id: str | None = None,
        chapter_id: str | None = None,
        lesson_id: str | None = None,
    ) -> SessionFileResult:
        conversation = self.ensure_conversation(conversation_id, mode=mode)
        session_id = str(uuid4())
        safe_name = Path(filename).name or "upload.bin"
        directory = self.storage_root / "sessions" / conversation_id
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{session_id}_{safe_name}"
        path.write_bytes(content)

        analysis = self.pipeline.analyze(path)
        source = Source(
            grade_id=grade_id,
            subject_id=subject_id,
            course_id=course_id,
            chapter_id=chapter_id,
            lesson_id=lesson_id,
            title=analysis.path.stem,
            source_type=analysis.source_type,
            scope=SourceScope.SESSION,
            status=SourceStatus.PROCESSING,
            storage_key=str(path),
            metadata_json={"conversation_id": conversation_id, "original_filename": safe_name},
        )
        self.db.add(source)
        self.db.flush()

        job = IngestionJob(source_id=source.id, details={"conversation_id": conversation_id, "filename": safe_name})
        self.db.add(job)

        session_file = SessionFile(
            id=session_id,
            conversation_id=conversation_id,
            source_id=source.id,
            filename=safe_name,
            storage_key=str(path),
            mime_type=mime_type or analysis.mime_type,
            size_bytes=len(content),
            status=SourceStatus.PROCESSING,
            required_capabilities=sorted(cap.value for cap in analysis.requires),
            metadata_json={"source_type": analysis.source_type.value},
        )
        self.db.add(session_file)
        self.db.flush()

        try:
            result = self.pipeline.process(path)
            session_file.extracted_text = result.document.text or None
            session_file.required_capabilities = sorted(cap.value for cap in result.required_capabilities)
            session_file.chunks_json = [
                {
                    "id": chunk.chunk_id,
                    "text": chunk.text,
                    "index": chunk.index,
                    "metadata": {**chunk.metadata, "source_id": source.id, "session_file_id": session_file.id},
                    "page": chunk.location.page if chunk.location else None,
                    "start_time": chunk.location.start_time if chunk.location else None,
                    "end_time": chunk.location.end_time if chunk.location else None,
                    "url": chunk.location.url if chunk.location else None,
                }
                for chunk in result.chunks
            ]
            if self.session_index is not None and session_file.chunks_json:
                index_items = []
                for item in session_file.chunks_json:
                    index_items.append({
                        "id": f"{session_file.id}:{item['id']}",
                        "text": item["text"],
                        "source_id": source.id,
                        "session_file_id": session_file.id,
                        "title": result.document.title or safe_name,
                        "metadata": item.get("metadata", {}),
                        "location": {
                            "page": item.get("page"),
                            "start_time_seconds": item.get("start_time"),
                            "end_time_seconds": item.get("end_time"),
                            "url": item.get("url"),
                        },
                    })
                index_result = self.session_index.index_chunks(index_items)
            else:
                index_result = None
            session_file.metadata_json.update({"title": result.document.title, "warnings": list(result.warnings)})
            source.metadata_json.update({"conversation_id": conversation_id, "session_file_id": session_file.id})
            version = SourceVersion(
                source_id=source.id,
                version_number=1,
                extracted_text=result.document.text or None,
                metadata_json={"chunk_count": len(result.chunks), "required_capabilities": sorted(cap.value for cap in result.required_capabilities)},
            )
            self.db.add(version)
            job.status = "succeeded"
            job.attempt = 1
            job.details.update({"chunk_count": len(result.chunks), "required_capabilities": sorted(cap.value for cap in result.required_capabilities), "indexed_chunks": index_result.indexed if index_result else 0, "index_collection": index_result.collection if index_result else None})
            if result.chunks or result.document.text:
                session_file.status = SourceStatus.APPROVED
                source.status = SourceStatus.APPROVED
            else:
                session_file.status = SourceStatus.PROCESSING
                source.status = SourceStatus.PROCESSING
            self.db.commit()
            if index_result is not None:
                session_file.metadata_json["indexed_chunks"] = index_result.indexed
                session_file.metadata_json["index_collection"] = index_result.collection
            self.db.commit()
            return SessionFileResult(session_file, source, result.warnings, bool(index_result and index_result.indexed) or bool(result.document.text))
        except Exception as exc:
            session_file.status = SourceStatus.FAILED
            source.status = SourceStatus.FAILED
            job.status = "failed"
            job.attempt = 1
            job.error_message = str(exc)
            self.db.commit()
            raise

    def get_context(self, file_ids: Iterable[str], *, conversation_id: str) -> list[FileContext]:
        ids = list(file_ids)
        if not ids:
            return []
        rows = self.db.scalars(
            select(SessionFile).where(
                SessionFile.id.in_(ids),
                SessionFile.conversation_id == conversation_id,
            )
        ).all()
        return [FileContext(row.id, row.filename, row.extracted_text or "") for row in rows if row.extracted_text]
