# Provider Orchestrator — Phase 4

Phase 4 adds provider/model orchestration without coupling the core to a real vendor.

## Capabilities
- Provider and model registry
- Capability matching (chat, vision, embedding, OCR, transcription, reranking, structured output, web search)
- Deterministic policy scoring using quality, latency, cost, and provider priority
- Per-provider/per-capability health state
- Circuit breaker with closed/open/half-open states
- Health-aware fallback
- Bounded execution attempts
- Provider adapter contract ready for real OpenAI-compatible, Google, Qwen, NVIDIA, OpenRouter, local and custom adapters

## Important
No real external API keys are required in this phase. `MockProviderAdapter` is used by tests only.
Real adapters are intentionally deferred until the configuration and provider policy surface is finalized.
