from __future__ import annotations

from dataclasses import dataclass

from backend_v2.core.enums import Capability
from backend_v2.providers.contracts import ModelProfile, ProviderAdapter, ProviderProfile


@dataclass(slots=True)
class RegisteredProvider:
    adapter: ProviderAdapter
    profile: ProviderProfile
    priority: int = 100
    enabled: bool = True

    def candidate_models(self, capability: Capability) -> tuple[ModelProfile, ...]:
        if not self.enabled or not self.profile.enabled:
            return ()
        return self.profile.candidates(capability)


class ProviderRegistry:
    def __init__(self) -> None:
        self._providers: dict[str, RegisteredProvider] = {}

    def register(
        self,
        adapter: ProviderAdapter,
        *,
        priority: int = 100,
        enabled: bool = True,
        models: tuple[ModelProfile, ...] | None = None,
    ) -> None:
        if models is None:
            models = (
                ModelProfile(
                    model=getattr(adapter, "default_model", adapter.provider_name),
                    capabilities=frozenset(cap for cap in Capability if adapter.supports(cap)),
                    priority=priority,
                ),
            )
        profile = ProviderProfile(
            name=adapter.provider_name,
            models=tuple(models),
            priority=priority,
            enabled=enabled,
        )
        self._providers[adapter.provider_name] = RegisteredProvider(
            adapter=adapter,
            profile=profile,
            priority=priority,
            enabled=enabled,
        )

    def get(self, provider_name: str) -> RegisteredProvider | None:
        return self._providers.get(provider_name)

    def providers(self) -> tuple[RegisteredProvider, ...]:
        return tuple(self._providers.values())

    def get_candidates(self, capability: Capability) -> list[RegisteredProvider]:
        candidates = [
            item for item in self._providers.values()
            if item.enabled and item.profile.enabled and item.candidate_models(capability)
        ]
        return sorted(candidates, key=lambda item: item.priority)
