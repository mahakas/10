from __future__ import annotations

from fastapi import FastAPI

from backend_v2.api.catalog import router as catalog_router
from backend_v2.api.chat import router as chat_router
from backend_v2.api.general_chat import router as general_chat_router
from backend_v2.api.sources import router as sources_router
from backend_v2.api.uploads import router as uploads_router
from backend_v2.database.connection import create_all


def create_app() -> FastAPI:
    create_all()
    app = FastAPI(title="Mahak AI v2", version="0.5.0")
    app.include_router(catalog_router, prefix="/api")
    app.include_router(chat_router, prefix="/api")
    app.include_router(general_chat_router, prefix="/api")
    app.include_router(sources_router, prefix="/api")
    app.include_router(uploads_router, prefix="/api")

    @app.get("/api/health")
    def health():
        return {"status": "ok", "version": "0.5.0"}

    return app


app = create_app()
