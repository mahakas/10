from __future__ import annotations

from pydantic import BaseModel, Field


class GradeCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    sort_order: int = 0


class GradeOut(BaseModel):
    id: str
    name: str
    sort_order: int
    is_active: bool

    model_config = {"from_attributes": True}


class SubjectCreate(BaseModel):
    name: str = Field(min_length=1, max_length=150)
    sort_order: int = 0


class SubjectOut(BaseModel):
    id: str
    grade_id: str
    name: str
    sort_order: int
    is_active: bool

    model_config = {"from_attributes": True}


class CourseCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str | None = None


class CourseOut(BaseModel):
    id: str
    subject_id: str
    name: str
    description: str | None
    is_active: bool

    model_config = {"from_attributes": True}
