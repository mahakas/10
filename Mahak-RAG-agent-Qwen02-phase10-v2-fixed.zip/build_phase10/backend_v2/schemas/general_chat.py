from __future__ import annotations

from pydantic import BaseModel, Field


class GeneralChatRequest(BaseModel):
    conversation_id: str = Field(min_length=1)
    query: str = Field(min_length=1, max_length=8000)
    session_file_ids: list[str] = Field(default_factory=list)
    use_web: bool | None = None
    top_k_web: int = Field(default=5, ge=1, le=10)


class GeneralCitationOut(BaseModel):
    title: str
    url: str | None = None
    snippet: str


class GeneralChatResponseOut(BaseModel):
    answer: str
    used_web: bool
    used_files: bool
    provider: str | None = None
    model: str | None = None
    web_provider: str | None = None
    citations: list[GeneralCitationOut] = Field(default_factory=list)
