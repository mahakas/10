from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class VectorRecord:
    id: str
    embedding: list[float]
    document: str
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class VectorHit:
    id: str
    score: float
    document: str
    metadata: dict[str, Any]


class VectorStore(Protocol):
    name: str

    def upsert(self, records: list[VectorRecord], *, collection: str) -> None: ...

    def search(self, query_embedding: list[float], *, collection: str, top_k: int = 10, filters: dict[str, Any] | None = None) -> list[VectorHit]: ...

    def delete(self, ids: list[str], *, collection: str) -> None: ...

    def health_check(self) -> bool: ...
