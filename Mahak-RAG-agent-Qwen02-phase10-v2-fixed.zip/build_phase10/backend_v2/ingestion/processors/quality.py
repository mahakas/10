from __future__ import annotations

from dataclasses import dataclass, field

from backend_v2.ingestion.document import ContentChunk, ExtractedDocument


@dataclass(frozen=True, slots=True)
class QualityReport:
    readable: bool
    has_content: bool
    text_length: int
    chunk_count: int
    warnings: tuple[str, ...] = field(default_factory=tuple)

    @property
    def accepted_for_indexing(self) -> bool:
        return self.readable and (self.has_content or self.chunk_count > 0)


class QualityChecker:
    def check(self, document: ExtractedDocument, chunks: list[ContentChunk]) -> QualityReport:
        warnings: list[str] = []
        text_length = len(document.text.strip())
        has_content = text_length > 0 or bool(document.metadata.get("path"))
        if document.source_type.value in {"image", "video"} and not document.text.strip():
            warnings.append("text_content_not_available_before_provider_processing")
        if document.source_type.value == "pdf" and not document.text.strip():
            warnings.append("pdf_has_no_extractable_text; OCR_or_vision_required")
        return QualityReport(
            readable=True,
            has_content=has_content,
            text_length=text_length,
            chunk_count=len(chunks),
            warnings=tuple(warnings),
        )
