from pathlib import Path

from docx import Document
from PIL import Image
from pypdf import PdfWriter

from backend_v2.core.enums import Capability, SourceType
from backend_v2.ingestion import IngestionPipeline


def write_pdf(path: Path) -> None:
    writer = PdfWriter()
    writer.add_blank_page(width=300, height=300)
    with path.open("wb") as fh:
        writer.write(fh)


def test_txt_pipeline_and_chunking(tmp_path: Path):
    file = tmp_path / "physics.txt"
    file.write_text("قانون اول نیوتن.\n\nجسم تا زمانی که نیروی خالصی بر آن وارد نشود، حالت حرکت خود را حفظ می‌کند.", encoding="utf-8")
    result = IngestionPipeline(chunk_size=80, overlap=10).process(file)
    assert result.analysis.source_type is SourceType.TXT
    assert result.chunks
    assert result.ready_for_embedding
    assert not result.required_capabilities


def test_markdown_uses_text_loader(tmp_path: Path):
    file = tmp_path / "lesson.md"
    file.write_text("# فصل اول\n\nمقدمه‌ای درباره حرکت.", encoding="utf-8")
    result = IngestionPipeline().process(file)
    assert result.analysis.source_type is SourceType.MD
    assert "مقدمه" in result.document.text


def test_docx_extraction(tmp_path: Path):
    file = tmp_path / "lesson.docx"
    doc = Document()
    doc.add_paragraph("قانون دوم نیوتن")
    table = doc.add_table(rows=1, cols=2)
    table.rows[0].cells[0].text = "F"
    table.rows[0].cells[1].text = "ma"
    doc.save(file)
    result = IngestionPipeline().process(file)
    assert result.analysis.source_type is SourceType.DOCX
    assert "قانون دوم نیوتن" in result.document.text
    assert "F | ma" in result.document.text


def test_html_cleanup(tmp_path: Path):
    file = tmp_path / "lesson.html"
    file.write_text("<html><head><title>فیزیک</title><style>bad</style></head><body><h1>حرکت</h1><script>bad()</script><p>سرعت یعنی...</p></body></html>", encoding="utf-8")
    result = IngestionPipeline().process(file)
    assert result.analysis.source_type is SourceType.HTML
    assert result.document.title == "فیزیک"
    assert "bad" not in result.document.text
    assert "سرعت یعنی" in result.document.text


def test_pdf_with_no_text_requests_ocr_or_vision(tmp_path: Path):
    file = tmp_path / "scan.pdf"
    write_pdf(file)
    result = IngestionPipeline().process(file)
    assert result.analysis.source_type is SourceType.PDF
    assert Capability.OCR in result.required_capabilities
    assert Capability.VISION in result.required_capabilities
    assert any("OCR" in warning or "ocr" in warning for warning in result.warnings)


def test_image_requires_vision(tmp_path: Path):
    file = tmp_path / "diagram.png"
    Image.new("RGB", (32, 24), "white").save(file)
    result = IngestionPipeline().process(file)
    assert result.analysis.source_type is SourceType.IMAGE
    assert Capability.VISION in result.required_capabilities
    assert result.document.metadata["width"] == 32
    assert not result.chunks


def test_video_is_deferred_to_provider_processing(tmp_path: Path):
    file = tmp_path / "class.mp4"
    file.write_bytes(b"placeholder")
    result = IngestionPipeline().process(file)
    assert result.analysis.source_type is SourceType.VIDEO
    assert Capability.VISION in result.required_capabilities
    assert Capability.TRANSCRIPTION in result.required_capabilities
    assert result.needs_provider_processing


def test_unknown_extension_is_rejected(tmp_path: Path):
    file = tmp_path / "data.xyz"
    file.write_text("hello", encoding="utf-8")
    pipeline = IngestionPipeline()
    analysis = pipeline.analyze(file)
    assert analysis.source_type is SourceType.OTHER
    try:
        pipeline.process(file)
    except ValueError as exc:
        assert "Unsupported source type" in str(exc)
    else:
        raise AssertionError("Unsupported type did not fail")


def test_normalization_is_unicode_safe(tmp_path: Path):
    file = tmp_path / "unicode.txt"
    file.write_text("الف   ب\r\n\r\n\r\n  ج", encoding="utf-8")
    result = IngestionPipeline().process(file)
    assert result.document.text == "الف ب\n\nج"
