from backend_v2.core.enums import Capability
from backend_v2.providers.adapters.mock import MockProviderAdapter
from backend_v2.providers.health import ProviderHealthManager
from backend_v2.providers.orchestrator import ProviderOrchestrator
from backend_v2.providers.registry import ProviderRegistry
from backend_v2.retrieval.citation_builder import citation_from_hit
from backend_v2.retrieval.hybrid import HybridReranker, lexical_score
from backend_v2.retrieval.query import RetrievalScope
from backend_v2.retrieval.service import RetrievalRequest, RetrievalService
from backend_v2.vectorstores.base import VectorRecord
from backend_v2.vectorstores.embedding import EmbeddingService
from backend_v2.vectorstores.memory import InMemoryVectorStore


def _service():
    registry = ProviderRegistry()
    registry.register(MockProviderAdapter("embed", {Capability.EMBEDDING}, default_model="embed-v1", embedding_dimension=4), priority=1)
    embedding = EmbeddingService(ProviderOrchestrator(registry, ProviderHealthManager()))
    return RetrievalService(InMemoryVectorStore(), embedding)


def test_scope_filters_are_sent_to_vector_store():
    service = _service()
    service.vector_store.upsert(
        [
            VectorRecord("p", [1, 0, 0, 0], "قانون دوم نیوتن", {"grade_id": "g10", "subject_id": "physics", "source_id": "s1"}),
            VectorRecord("c", [1, 0, 0, 0], "واکنش شیمیایی", {"grade_id": "g10", "subject_id": "chem", "source_id": "s2"}),
        ],
        collection="kb",
    )
    result = service.retrieve(RetrievalRequest("نیوتن", RetrievalScope("g10", "physics"), "kb", min_score=0.2))
    assert [hit.id for hit in result.accepted] == ["p"]
    assert result.filters == {"grade_id": "g10", "subject_id": "physics"}


def test_retrieval_reranks_using_lexical_overlap():
    reranker = HybridReranker(vector_weight=0.5, lexical_weight=0.5)
    from backend_v2.vectorstores.base import VectorHit
    hits = [
        VectorHit("a", 0.95, "این متن درباره انرژی است", {}),
        VectorHit("b", 0.80, "قانون دوم نیوتن و نیرو", {}),
    ]
    ranked = reranker.rerank("قانون دوم نیوتن", hits)
    assert ranked[0].id == "b"
    assert ranked[0].score > ranked[1].score


def test_low_confidence_results_are_rejected():
    service = _service()
    service.vector_store.upsert(
        [VectorRecord("x", [0, 1, 0, 0], "موضوع نامرتبط", {"grade_id": "g10"})],
        collection="kb",
    )
    result = service.retrieve(RetrievalRequest("موضوع دیگر", RetrievalScope(grade_id="g10"), "kb", min_score=0.99))
    assert not result.found
    assert [hit.id for hit in result.rejected] == ["x"]


def test_empty_query_is_rejected():
    service = _service()
    try:
        service.retrieve(RetrievalRequest("  ", RetrievalScope(), "kb"))
    except ValueError as exc:
        assert "empty" in str(exc).lower()
    else:
        raise AssertionError("Empty query did not fail")


def test_source_aware_citation_from_hit():
    from backend_v2.vectorstores.base import VectorHit
    hit = VectorHit(
        "chunk-1",
        0.91,
        "محتوای صفحه",
        {"source_id": "src1", "title": "فیزیک دهم", "url": "https://example.test/book.pdf", "page": 42},
    )
    citation = citation_from_hit(hit)
    assert citation.source_id == "src1"
    assert citation.title == "فیزیک دهم"
    assert citation.page == 42
    assert citation.url.endswith("book.pdf")


def test_persian_text_normalization_and_lexical_score():
    assert lexical_score("قانون كلی", "قانون کلی فیزیک") > 0.0
